﻿namespace BankManagementSystem.Common.Constants
{
    public class ViewNameConstants
    {
        public const string Purchase = "Purchase";
    }
}
