﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankManagementSystem.Common.Constants
{
    public static class ControllerConstants
    {
        public const string CreditCards = "CreditCards";
        public const string Assets = "Assets";
    }
}
