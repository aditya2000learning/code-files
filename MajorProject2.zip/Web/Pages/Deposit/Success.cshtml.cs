﻿namespace BankManagementSystem.Web.Pages.Deposit
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc.RazorPages;

    [Authorize]
    public class SuccessModel : PageModel
    {
    }
}