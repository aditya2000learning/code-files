﻿namespace BankManagementSystem.Web.Pages.Credit
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc.RazorPages;

    [Authorize]
    public class SuccessModel : PageModel
    {
    }
}